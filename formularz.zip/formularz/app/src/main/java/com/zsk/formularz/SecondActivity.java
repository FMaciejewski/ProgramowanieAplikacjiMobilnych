package com.zsk.formularz;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
    }

    public void onClick(View view){
        EditText name = findViewById(R.id.imie);
        EditText etemail = findViewById(R.id.email);
        EditText ethaslo = findViewById(R.id.haslo);
        String imie = name.getText().toString();
        String email = etemail.getText().toString();
        String haslo = ethaslo.getText().toString();
        if(!imie.isEmpty() && email.contains("@") && haslo.matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).+$")){
            Intent intent = new Intent();
            intent.putExtra("imie", imie);
            setResult(RESULT_OK, intent);
            finish();
        }
        else{
            String wiadomosc = "Podano błędne ";
            if (imie.isEmpty()){
                wiadomosc += "imie ";
            }
            if (!email.contains("@")){
                wiadomosc += "email ";
            }
            if (!haslo.matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).+$")){
                wiadomosc += "hasło ";
            }
            Toast.makeText(this, wiadomosc, Toast.LENGTH_SHORT).show();
        }

    }
}
