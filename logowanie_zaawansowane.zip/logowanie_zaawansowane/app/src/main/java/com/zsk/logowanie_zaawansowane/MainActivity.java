package com.zsk.logowanie_zaawansowane;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    int myCode = 1;
    public static List<User> users = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
    }

    public void toRegister(View view){
        startActivityForResult(new Intent(this, SecondActivity.class), myCode);
    }

    public void LogIn(View view){
        EditText etEmail = findViewById(R.id.email_login);
        EditText etPassword = findViewById(R.id.password_login);
        String email = etEmail.getText().toString();
        String password = etPassword.getText().toString();

        boolean logged = false;
        for(User u : users){
            if(u.email.equals(email) && u.password.equals(password)){
                startActivityForResult(new Intent(this, ThirdActivity.class), myCode);
                logged = true;
            }
        }
        if(!logged){
            Toast.makeText(this, "Błędne dane logowania", Toast.LENGTH_SHORT).show();
        }
    }
}