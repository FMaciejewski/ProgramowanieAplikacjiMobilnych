package com.zsk.logowanie_zaawansowane;

public class User {
    String email;
    String password;
    String pesel;

    public User(String email, String password, String pesel){
        this.email = email;
        this.password = password;
        this.pesel = pesel;
    }
}
