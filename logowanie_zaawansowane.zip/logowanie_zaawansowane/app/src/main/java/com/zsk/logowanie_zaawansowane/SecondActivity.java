package com.zsk.logowanie_zaawansowane;

import static com.zsk.logowanie_zaawansowane.MainActivity.users;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_layout);
    }

    public void Confirm(View view){
        EditText etEmail = findViewById(R.id.register_email);
        EditText etPassword = findViewById(R.id.register_password);
        EditText etRapePassword = findViewById(R.id.register_password_repeat);
        EditText etPesel = findViewById(R.id.register_pesel);
        String email = etEmail.getText().toString();
        String password = etPassword.getText().toString();
        String rapePassword = etRapePassword.getText().toString();
        String pesel = etPesel.getText().toString();

        int[] weights = {1, 3, 7, 9, 1, 3, 7, 9, 1, 3};

        int sum = 0;
        for (int i = 0; i < 10; i++) {
            int digit = Character.getNumericValue(pesel.charAt(i));
            sum += digit * weights[i];
        }

        int control = (10 - (sum % 10)) % 10;
        int lastDigit = Character.getNumericValue(pesel.charAt(10));

        if(email.contains("@") && password.matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).+$") && password.equals(rapePassword) && pesel.matches("\\d{11}") && control == lastDigit){
            User user = new User(email, password, pesel);
            users.add(user);
            Intent intent = new Intent();
            setResult(RESULT_OK, intent);
            finish();
        }
        else{
            String wiadomosc = "Podano błędne: ";
            if(!email.contains("@")){
                wiadomosc += "email ";
            }
            if(!password.matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).+$")){
                wiadomosc += "haslo ";
            }
            if(!password.equals(rapePassword)){
                wiadomosc += "błędnie powtórzone hasło";
            }
            if(pesel.matches("\\d{11}") && control == lastDigit){
                wiadomosc += "pesel";
            }
            Toast.makeText(this, wiadomosc, Toast.LENGTH_SHORT).show();
        }
    }
}
